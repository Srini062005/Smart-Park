"""
SmartPark - Intelligent Parking Allocation System
Flask application entry point.
"""

import os
from datetime import datetime
from functools import wraps
from flask import Flask, render_template, request, redirect, url_for, flash
from flask_login import LoginManager, login_user, logout_user, login_required, current_user

from config import Config
from models import db, User, Vehicle, ParkingSlot, Booking

app = Flask(__name__)
app.config.from_object(Config)

db.init_app(app)
login_manager = LoginManager()
login_manager.init_app(app)
login_manager.login_view = 'login'
login_manager.login_message = 'Please log in to access this page.'


@login_manager.user_loader
def load_user(user_id):
    return User.query.get(int(user_id))


# ---------- Authentication ----------

@app.route('/')
def index():
    if current_user.is_authenticated:
        if current_user.is_admin:
            return redirect(url_for('admin_dashboard'))
        return redirect(url_for('dashboard'))
    return redirect(url_for('login'))


@app.route('/login', methods=['GET', 'POST'])
def login():
    if current_user.is_authenticated:
        return redirect(url_for('dashboard'))
    if request.method == 'POST':
        email = request.form.get('email', '').strip()
        password = request.form.get('password', '')
        user = User.query.filter_by(email=email).first()
        if user and user.check_password(password):
            login_user(user)
            next_page = request.args.get('next')
            if next_page:
                return redirect(next_page)
            if user.is_admin:
                return redirect(url_for('admin_dashboard'))
            return redirect(url_for('dashboard'))
        flash('Invalid email or password.', 'error')
    return render_template('login.html')


@app.route('/register', methods=['GET', 'POST'])
def register():
    if current_user.is_authenticated:
        return redirect(url_for('dashboard'))
    if request.method == 'POST':
        name = request.form.get('name', '').strip()
        email = request.form.get('email', '').strip()
        password = request.form.get('password', '')
        if not name or not email or not password:
            flash('All fields are required.', 'error')
            return render_template('register.html')
        if User.query.filter_by(email=email).first():
            flash('Email already registered.', 'error')
            return render_template('register.html')
        user = User(name=name, email=email, role='user')
        user.set_password(password)
        db.session.add(user)
        db.session.commit()
        flash('Registration successful. Please log in.', 'success')
        return redirect(url_for('login'))
    return render_template('register.html')


@app.route('/logout')
@login_required
def logout():
    logout_user()
    flash('You have been logged out.', 'success')
    return redirect(url_for('login'))


# ---------- User Dashboard ----------

@app.route('/dashboard')
@login_required
def dashboard():
    if current_user.is_admin:
        return redirect(url_for('admin_dashboard'))
    vehicles = Vehicle.query.filter_by(user_id=current_user.id).all()
    active_booking = Booking.query.filter_by(
        user_id=current_user.id,
        exit_time=None
    ).first()
    past_bookings = Booking.query.filter(
        Booking.user_id == current_user.id,
        Booking.exit_time.isnot(None)
    ).order_by(Booking.exit_time.desc()).limit(20).all()
    return render_template('dashboard.html',
        vehicles=vehicles,
        active_booking=active_booking,
        past_bookings=past_bookings
    )


# ---------- Vehicle CRUD ----------

@app.route('/vehicles')
@login_required
def vehicles():
    if current_user.is_admin:
        return redirect(url_for('admin_dashboard'))
    vehicles = Vehicle.query.filter_by(user_id=current_user.id).all()
    return render_template('vehicles.html', vehicles=vehicles)


@app.route('/vehicles/add', methods=['GET', 'POST'])
@login_required
def add_vehicle():
    if current_user.is_admin:
        return redirect(url_for('admin_dashboard'))
    if request.method == 'POST':
        license_no = request.form.get('license_no', '').strip().upper()
        vehicle_type = request.form.get('vehicle_type', '').strip()
        if not license_no or not vehicle_type:
            flash('License number and vehicle type are required.', 'error')
            return render_template('add_vehicle.html')
        vehicle = Vehicle(
            user_id=current_user.id,
            license_no=license_no,
            vehicle_type=vehicle_type
        )
        db.session.add(vehicle)
        db.session.commit()
        flash('Vehicle added successfully.', 'success')
        return redirect(url_for('vehicles'))
    return render_template('add_vehicle.html')


@app.route('/vehicles/<int:vehicle_id>/delete', methods=['POST'])
@login_required
def delete_vehicle(vehicle_id):
    vehicle = Vehicle.query.get_or_404(vehicle_id)
    if vehicle.user_id != current_user.id:
        flash('Not allowed.', 'error')
        return redirect(url_for('vehicles'))
    active = Booking.query.filter_by(vehicle_id=vehicle_id, exit_time=None).first()
    if active:
        flash('Cannot delete vehicle with an active booking. End the booking first.', 'error')
        return redirect(url_for('vehicles'))
    db.session.delete(vehicle)
    db.session.commit()
    flash('Vehicle deleted.', 'success')
    return redirect(url_for('vehicles'))


# ---------- Booking ----------

@app.route('/booking/new', methods=['GET', 'POST'])
@login_required
def new_booking():
    if current_user.is_admin:
        return redirect(url_for('admin_dashboard'))
    vehicles = Vehicle.query.filter_by(user_id=current_user.id).all()
    if not vehicles:
        flash('Add at least one vehicle before creating a booking.', 'error')
        return redirect(url_for('add_vehicle'))
    active = Booking.query.filter_by(user_id=current_user.id, exit_time=None).first()
    if active:
        flash('You already have an active booking. End it before creating a new one.', 'error')
        return redirect(url_for('dashboard'))
    if request.method == 'POST':
        vehicle_id = request.form.get('vehicle_id', type=int)
        slot_type = request.form.get('slot_type', '').strip()
        if not vehicle_id or not slot_type:
            flash('Select vehicle and slot type.', 'error')
            return render_template('new_booking.html', vehicles=vehicles)
        vehicle = Vehicle.query.filter_by(id=vehicle_id, user_id=current_user.id).first()
        if not vehicle:
            flash('Invalid vehicle.', 'error')
            return render_template('new_booking.html', vehicles=vehicles)
        slot = ParkingSlot.query.filter_by(
            slot_type=slot_type,
            is_available=True
        ).first()
        if not slot:
            flash(f'No available slots of type "{slot_type}".', 'error')
            return render_template('new_booking.html', vehicles=vehicles)
        slot.is_available = False
        entry_time = datetime.utcnow()
        booking = Booking(
            user_id=current_user.id,
            vehicle_id=vehicle_id,
            parking_slot_id=slot.id,
            entry_time=entry_time,
            exit_time=None,
            fee=0.0
        )
        db.session.add(booking)
        db.session.commit()
        flash(f'Booking created! Slot {slot.location} allocated.', 'success')
        return redirect(url_for('dashboard'))
    return render_template('new_booking.html', vehicles=vehicles)


@app.route('/booking/<int:booking_id>/end', methods=['POST'])
@login_required
def end_booking(booking_id):
    booking = Booking.query.get_or_404(booking_id)
    if booking.user_id != current_user.id:
        flash('Not allowed.', 'error')
        return redirect(url_for('dashboard'))
    if booking.exit_time is not None:
        flash('Booking already ended.', 'error')
        return redirect(url_for('dashboard'))
    exit_time = datetime.utcnow()
    duration_hours = (exit_time - booking.entry_time).total_seconds() / 3600
    if duration_hours < 0.25:
        duration_hours = 0.25
    price_per_hour = ParkingSlot.PRICE_PER_HOUR.get(
        booking.parking_slot.slot_type, 20
    )
    fee = round(duration_hours * price_per_hour, 2)
    booking.exit_time = exit_time
    booking.fee = fee
    slot = ParkingSlot.query.get(booking.parking_slot_id)
    slot.is_available = True
    db.session.commit()
    flash(f'Booking ended. Fee: ₹{fee}', 'success')
    return redirect(url_for('dashboard'))


# ---------- Admin ----------

def admin_required(f):
    @wraps(f)
    def decorated(*args, **kwargs):
        if not current_user.is_authenticated or not current_user.is_admin:
            flash('Admin access required.', 'error')
            return redirect(url_for('login'))
        return f(*args, **kwargs)
    return decorated


@app.route('/admin')
@login_required
@admin_required
def admin_dashboard():
    slots = ParkingSlot.query.order_by(ParkingSlot.slot_type, ParkingSlot.id).all()
    active_bookings = Booking.query.filter_by(exit_time=None).all()
    completed_bookings = Booking.query.filter(
        Booking.exit_time.isnot(None)
    ).order_by(Booking.exit_time.desc()).limit(50).all()
    total_revenue = db.session.query(db.func.sum(Booking.fee)).filter(
        Booking.exit_time.isnot(None)
    ).scalar() or 0
    return render_template('admin_dashboard.html',
        slots=slots,
        active_bookings=active_bookings,
        completed_bookings=completed_bookings,
        total_revenue=total_revenue
    )


# ---------- Init DB and Seed ----------

@app.cli.command('init-db')
def init_db():
    """Create all tables and optionally seed data."""
    db.create_all()
    print('Tables created.')


@app.cli.command('seed')
def seed():
    """Seed admin user and sample parking slots."""
    if User.query.filter_by(email='admin@smartpark.com').first():
        print('Admin user already exists.')
        return
    admin = User(name='Admin', email='admin@smartpark.com', role='admin')
    admin.set_password('admin123')
    db.session.add(admin)
    slots_data = [
        ('Standard', 'A-1'), ('Standard', 'A-2'), ('Standard', 'A-3'),
        ('Premium', 'B-1'), ('Premium', 'B-2'),
        ('EV', 'C-1'), ('EV', 'C-2'),
    ]
    for slot_type, location in slots_data:
        s = ParkingSlot(slot_type=slot_type, location=location, is_available=True)
        db.session.add(s)
    db.session.commit()
    print('Seeded admin user (admin@smartpark.com / admin123) and sample slots.')


if __name__ == '__main__':
    app.run(debug=True, port=5000)
