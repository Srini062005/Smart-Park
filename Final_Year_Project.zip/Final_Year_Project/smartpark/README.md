# SmartPark - Intelligent Parking Allocation System

A college major project web app for intelligent parking slot allocation.

## Tech Stack

- **Backend:** Python, Flask
- **Frontend:** HTML, CSS, JavaScript
- **Database:** MySQL
- **ORM:** SQLAlchemy

## Setup

### 1. Create MySQL database

```sql
CREATE DATABASE smartpark;
```

### 2. Configure database connection

Edit `config.py` and set your MySQL credentials:

```python
SQLALCHEMY_DATABASE_URI = 'mysql+pymysql://USER:PASSWORD@localhost:3306/smartpark'
```

Or set the `DATABASE_URL` environment variable.

### 3. Install dependencies

```bash
cd smartpark
pip install -r requirements.txt
```

### 4. Initialize database and seed data

```bash
flask init-db
flask seed
```

This creates all tables and seeds:
- Admin user: `admin@smartpark.com` / `admin123`
- Sample parking slots (Standard, Premium, EV)

### 5. Run the app

```bash
flask run
```

Or:

```bash
python app.py
```

Open http://127.0.0.1:5000

## Usage

- **Register** a new user, then **Login**
- Add vehicles under **My Vehicles**
- Create a **New Booking** (select vehicle + slot type)
- **End Booking** when done; fee is calculated automatically
- **Admin** (admin@smartpark.com): view all slots, bookings, revenue

## Pricing

- Standard: ₹20/hr
- Premium: ₹40/hr
- EV Charging: ₹30/hr
