"""
SmartPark - Database models for User, Vehicle, ParkingSlot, Booking.
Uses SQLAlchemy ORM with MySQL.
"""

from flask_sqlalchemy import SQLAlchemy
from flask_login import UserMixin
from werkzeug.security import generate_password_hash, check_password_hash
from datetime import datetime

db = SQLAlchemy()


class User(UserMixin, db.Model):
    """User model: id, name, email, password_hash, role ('user' or 'admin')."""
    __tablename__ = 'user'

    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(100), nullable=False)
    email = db.Column(db.String(120), unique=True, nullable=False)
    password_hash = db.Column(db.String(255), nullable=False)
    role = db.Column(db.String(20), default='user', nullable=False)  # 'user' or 'admin'
    created_at = db.Column(db.DateTime, default=datetime.utcnow)

    # Relationships
    vehicles = db.relationship('Vehicle', backref='owner', lazy=True, cascade='all, delete-orphan')
    bookings = db.relationship('Booking', backref='user', lazy=True, cascade='all, delete-orphan')

    def set_password(self, password):
        self.password_hash = generate_password_hash(password)

    def check_password(self, password):
        return check_password_hash(self.password_hash, password)

    @property
    def is_admin(self):
        return self.role == 'admin'


class Vehicle(db.Model):
    """Vehicle model: id, user_id (FK), license_no, vehicle_type."""
    __tablename__ = 'vehicle'

    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=False)
    license_no = db.Column(db.String(20), nullable=False)
    vehicle_type = db.Column(db.String(50), nullable=False)  # e.g. Car, Bike, etc.
    created_at = db.Column(db.DateTime, default=datetime.utcnow)

    bookings = db.relationship('Booking', backref='vehicle', lazy=True, cascade='all, delete-orphan')


class ParkingSlot(db.Model):
    """
    ParkingSlot model: id, slot_type, location, is_available.
    slot_type: 'Standard', 'Premium', 'EV'
    """
    __tablename__ = 'parking_slot'

    id = db.Column(db.Integer, primary_key=True)
    slot_type = db.Column(db.String(20), nullable=False)  # Standard, Premium, EV
    location = db.Column(db.String(100), nullable=False)
    is_available = db.Column(db.Boolean, default=True, nullable=False)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)

    bookings = db.relationship('Booking', backref='parking_slot', lazy=True)

    # Pricing per hour (in rupees) - used for fee calculation
    PRICE_PER_HOUR = {
        'Standard': 20,
        'Premium': 40,
        'EV': 30
    }


class Booking(db.Model):
    """
    Booking model: id, user_id, vehicle_id, parking_slot_id,
    entry_time, exit_time, fee.
    exit_time is None while booking is active.
    """
    __tablename__ = 'booking'

    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=False)
    vehicle_id = db.Column(db.Integer, db.ForeignKey('vehicle.id'), nullable=False)
    parking_slot_id = db.Column(db.Integer, db.ForeignKey('parking_slot.id'), nullable=False)
    entry_time = db.Column(db.DateTime, nullable=False)
    exit_time = db.Column(db.DateTime, nullable=True)  # None = active booking
    fee = db.Column(db.Float, default=0.0, nullable=False)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)

    @property
    def is_active(self):
        return self.exit_time is None
