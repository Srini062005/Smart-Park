"""
SmartPark - Configuration for Flask app and MySQL database.
"""

import os

# Base directory
BASE_DIR = os.path.abspath(os.path.dirname(__file__))


class Config:
    """Default configuration."""
    SECRET_KEY = os.environ.get('SECRET_KEY') or 'smartpark-dev-secret-key-change-in-production'
    SQLALCHEMY_DATABASE_URI = os.environ.get('DATABASE_URL') or \
        'mysql+pymysql://root:password@localhost:3306/smartpark'
    SQLALCHEMY_TRACK_MODIFICATIONS = False
    SQLALCHEMY_ECHO = False  # Set True to log SQL queries for debugging
